# Edge Combat — Minecraft 1.21.11 (одиночная и LAN)

Клавиша R включает/выключает AimAssist и TriggerBot. На чужом сервере мод отключается сам.
Настройки лежат в src/main/java/edge/toggle/Config.java.
