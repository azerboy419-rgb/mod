package edge.toggle;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class EdgeCombatToggle implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean aimAssistEnabled = false;
    private static boolean triggerBotEnabled = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.edge_combat_toggle.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                // This base intentionally changes only toggle state; no native DLLs or
                // automated combat actions are loaded or executed.
                boolean next = !(aimAssistEnabled && triggerBotEnabled);
                aimAssistEnabled = next;
                triggerBotEnabled = next;
                if (client.player != null) {
                    String state = next ? "ВКЛ" : "ВЫКЛ";
                    client.player.sendMessage(Text.literal(
                            "[Edge] AimAssist: " + state + " | TriggerBot: " + state
                    ), true);
                }
            }
        });
    }
}
