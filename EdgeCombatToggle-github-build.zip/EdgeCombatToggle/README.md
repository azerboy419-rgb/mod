# Edge Combat Toggle Base — Minecraft 1.21.11

This is a clean Fabric client-side starter project for Java 21, Fabric Loader 0.19.5 and Fabric API 0.141.6+1.21.11.

## Current behavior
- Press `R` to toggle the AimAssist and TriggerBot *state flags* together.
- Shows an action-bar message with the current states.
- Does not load native DLLs, use `Unsafe`, dump process memory, or open external links.

## Important limitation
This is a toggle foundation, **not a functional AimAssist/TriggerBot**. The supplied combat classes rely on the original project's custom `Client`/entity wrappers and native runtime; the standalone uploaded `TriggerBot.java` was only an empty stub. Those combat functions have not been wired into this clean base.

## Build
Requires JDK 21 and network access for Gradle/Fabric dependencies:

```bash
./gradlew build
```

The build could not be run in the current environment because the Gradle 9.7.1 distribution was not cached and network access to `services.gradle.org` was unavailable. No compiled JAR is included.
